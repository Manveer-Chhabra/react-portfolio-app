import { Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <VStack
      bg="white"
      borderRadius="lg"
      overflow="hidden"
      boxShadow="md"
      spacing={0}
      align="stretch"
    >
      <Image src={imageSrc} alt={title} objectFit="cover" />
      <VStack spacing={4} p={6} align="flex-start">
        <Heading as="h3" size="md" color="black">
          {title}
        </Heading>
        <Text color="gray.600" fontSize="sm">
          {description}
        </Text>
        <HStack spacing={2} color="black" fontSize="sm" fontWeight="bold">
          <Text>See more</Text>
          <FontAwesomeIcon icon={faArrowRight} size="1x" />
        </HStack>
      </VStack>
    </VStack>
  );
};

export default Card;
